# encoding: utf-8

from .fx_interface import *

__all__ = ['get_hist_cny_cpr', 'get_his_shibor', 'get_realtime_shibor', 'get_cny_spot_price']
