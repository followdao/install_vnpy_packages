# encoding: UTF-8

from .aqi_interface import *
from .constant import *

__all__ = ['get_daily_aqi', 'get_daily_aqi_onecity', 'get_hour_aqi_onecity', 'get_hour_aqi', 'set_proxies']
