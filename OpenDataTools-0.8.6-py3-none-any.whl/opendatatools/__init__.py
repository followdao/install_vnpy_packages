# encoding: utf-8
"""
    Open Data
    ~~~~
    Open source data tools
    copyright: (c) 2017 quantOS-org.
    license: Apache 2.0, see LICENSE for details.
"""

import os

__version__ = '0.8.6'
SOURCE_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

