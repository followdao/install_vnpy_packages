from .coin_interface import *

__all__ = ['set_proxies', 'get_coin_list', 'get_coin_snapshot', 'get_coin_price', 'get_his_min', 'get_his_hour', 'get_his_day']
