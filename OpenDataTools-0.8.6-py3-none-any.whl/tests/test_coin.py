# encoding: utf-8
from opendatatools import coin
import unittest

class TestCoin(unittest.TestCase):
    pass